# streamlit_star_rating
Star Rating Component for Streamlit Apps
